package yahtzee;

/* 
Livi Poon
CS2100 - Intermediate Programming
Explanation: threes calculates threes score given obj Dice and extends catagory
*/

public class Threes extends Catagory{

     /**
     * evaluates overrides abstract method evaluate in super class
     */

    // @Override
    public int evaluate(Dice d){
        int number = d.count(3);
        int score = number*3;

        return score;
    }
}

