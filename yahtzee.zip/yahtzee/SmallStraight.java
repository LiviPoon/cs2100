package yahtzee;

/* 
Livi Poon
CS2100 - Intermediate Programming
Explanation: smallStraight checks to see if there is a straight of four numbers, if so return 30, if not return 0
*/

public class SmallStraight extends Catagory{

     /**
     * evaluates overrides abstract method evaluate in super class
     */

    // @Override
    public int evaluate(Dice d){
        if (d.getNumDice() < 4) {
            // If there are less than 4 dice, it's not possible to have four consecutive numbers
            return 0;
        }

        

        // Check for four consecutive numbers
        for (int i = 0; i <= d.getNumDice() - 4; i++) {
            if (d.getDie(i).getValue() + 1 == d.getDie(i + 1).getValue()
                    && d.getDie(i + 1).getValue() + 1 == d.getDie(i + 2).getValue()
                    && d.getDie(i + 2).getValue() + 1 == d.getDie(i + 3).getValue()) {
                // Found four consecutive numbers
                return 30;
            }
        }

        return 0;
    }
}

