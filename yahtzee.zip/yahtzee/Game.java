package yahtzee;

import java.util.ArrayList;

/* 
Livi Poon
CS2100 - Intermediate Programming
Explanation: Game main driver
*/


public class Game {
    public static void main(String[] args){
        System.out.printf("Yahtzee, the Java edition.%n%n");

        Dice currentDice;
        int roll;
        ArrayList<Boolean> savedDice = new ArrayList<Boolean>(5); // Each value is associated with a die, True = saved and vis versa

        ScoreCard player1 = new ScoreCard();
        ScoreCard player2 = new ScoreCard();

        for(int round = 0; round==13; round++){
            for(int player =0; player < 2; round++){
                System.out.printf("Round: %d", round);
                System.out.printf()
            }

        }




    }
    


}
