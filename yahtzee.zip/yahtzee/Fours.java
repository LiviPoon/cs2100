package yahtzee;

/* 
Livi Poon
CS2100 - Intermediate Programming
Explanation: fours calculates fours score given obj Dice and extends catagory
*/

public class Fours extends Catagory{

     /**
     * evaluates overrides abstract method evaluate in super class
     */

    // @Override
    public int evaluate(Dice d){
        int number = d.count(4);
        int score = number*4;

        return score;
    }
}

