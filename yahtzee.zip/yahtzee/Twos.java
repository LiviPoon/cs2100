package yahtzee;

/* 
Livi Poon
CS2100 - Intermediate Programming
Explanation: twos calculates twos score given obj Dice and extends catagory
*/

public class Twos extends Catagory{

     /**
     * evaluates overrides abstract method evaluate in super class
     */

    // @Override
    public int evaluate(Dice d){
        int number = d.count(2);
        int score = number*2;

        return score;
    }
}

