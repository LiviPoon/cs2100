package yahtzee;

/* 
Livi Poon
CS2100 - Intermediate Programming
Explanation: LargeStraight checks to see if there is a straight of five numbers, if so return 40, if not return 0
*/

public class LargeStraight extends Catagory{

     /**
     * evaluates overrides abstract method evaluate in super class
     */

    // @Override
    public int evaluate(Dice d){
        if (d.getNumDice() < 4) {
            // If there are less than 4 dice, it's not possible to have four consecutive numbers
            return 0;
        }

        // Check for four consecutive numbers
        for (int i = 0; i <= d.getNumDice() - 5; i++) {
            if (d.getDie(i).getValue() + 1 == d.getDie(i + 1).getValue()
                    && d.getDie(i + 1).getValue() + 1 == d.getDie(i + 2).getValue()
                    && d.getDie(i + 2).getValue() + 1 == d.getDie(i + 3).getValue()
                    && d.getDie(i + 3).getValue() + 1 == d.getDie(i + 4).getValue()) {
                // Found five consecutive numbers
                return 40;
            }
        }

        return 0;
    }
}

