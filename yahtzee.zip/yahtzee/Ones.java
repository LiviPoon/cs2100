package yahtzee;

/* 
Livi Poon
CS2100 - Intermediate Programming
Explanation: Ones calculates ones score given obj Dice and extends catagory
*/

public class Ones extends Catagory {

     /**
     * evaluates overrides abstract method evaluate in super class
     */

    // @Override
    public int evaluate(Dice d){
        int number = d.count(1);
        int score = number*1;

        return score;
    }
}
